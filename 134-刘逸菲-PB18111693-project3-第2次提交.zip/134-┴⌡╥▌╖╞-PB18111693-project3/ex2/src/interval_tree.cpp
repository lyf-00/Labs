/*
 * @Author: lyf
 * @Date: 2020-12-22 18:41:58
 * @LastEditors: lyf
 * @LastEditTime: 2020-12-24 00:05:00
 * @FilePath: \134-刘逸菲-PB18111693-project3\ex2\src\interval_tree.cpp
 */
# include<stdio.h>
# include<stdlib.h>
# include <time.h>
# define RED true
# define BLACK false
# define SIZE 30
typedef int keyType;
typedef bool colortype;
struct node{
    keyType low;
    keyType high;
    keyType max;
    struct node * p,* right,* left;
    colortype color;
};
struct intervaltree {
    struct node * root;
    struct node * nil;
};
typedef struct node node;
typedef struct intervaltree intervaltree;

// function declaration
void left_rotate(intervaltree &T,node * x);
void right_rotate(intervaltree &T,node * x);
void interval_insert(intervaltree &T,node * &z);
void interval_insert_fixup(intervaltree &T,node * &z);
void in_order_print_intervaltree(FILE * f,intervaltree T);
void in_order_print(FILE * f,intervaltree &T,node* x);
node * tree_minimum(intervaltree T,node * x);
node * tree_successor(intervaltree T,node * x);
node * tree_search(intervaltree T,node * x,keyType low);
void interval_delete(intervaltree &T,node * z);
void interval_delete_fixup(intervaltree &T,node * x);
void max_change(intervaltree &T,node * x);
int is_overlap(keyType low1,keyType high1,keyType low2,keyType high2);


void init_intervaltree(intervaltree &T,node * &nil){
    T.nil = nil;
    T.root = T.nil;
}

void left_rotate(intervaltree &T,node * x){
    node * y = x->right;
    x->right = y->left;
    if (y->left != T.nil){
        y->left->p = x;
    }
    y->p = x->p;
    if(x->p == T.nil){
        T.root = y;
    } else if(x == x->p->left){
        x->p->left = y;
    } else {
        x->p->right = y;
    }
    y->left = x;
    x->p = y;

    // after rotation,change the max area of all nodes that are affected
    max_change(T,y->left);
    max_change(T,y->right);
    while(y != T.nil){
        max_change(T,y);
        y = y->p;
    }
}

void right_rotate(intervaltree &T,node * x){ 
    node * y = x->left;
    x->left = y->right;
    if (y->right != T.nil){
        y->right->p = x;
    }
    y->p = x->p; 
    if(x->p == T.nil){
        T.root = y;
    } else if(x == x->p->left){
        x->p->left = y;
    } else {
        x->p->right = y;
    }
    y->right = x;
    x->p = y;
    // after rotation,change the max area of all nodes that are affected
    max_change(T,y->left);
    max_change(T,y->right);
    while(y != T.nil){
        max_change(T,y);
        y = y->p;
    }
}

/**
 * @description:recompute the max area of node x in rbtree T 
 * @param {*}
 * @return {void}
 */
void max_change(intervaltree &T,node * x){
    // x.max = max(x.int.high,x.left.max,x.right.max)
    keyType largest = x->high;
    if(x->left != T.nil){
        if(x->left->max > largest)
            largest = x->left->max;
    }

    if(x->right != T.nil){
        if(x->right->max > largest)
            largest = x->right->max;
    }
    x->max = largest;
}

void interval_insert(intervaltree &T,node * &z){
    node * y = T.nil;
    node * x = T.root;
    while(x != T.nil){
        y = x;
        if(z->low < x->low){
            x = x->left;
        } else {
            x = x->right;
        }
    }
    z->p = y;
    z->max = z->high; // 插入结点的max域赋初值
    if(y == T.nil){
        T.root = z;
    } else if(z->low < y->low){
        y->left = z;
    } else {
        y->right = z;
    }
    z->left = z->right = T.nil;
    z->color = RED;
    // 修改z的祖先节点的max域
    while(y != T.nil) {
        max_change(T,y);
        y = y->p;
    }
    interval_insert_fixup(T,z);
}

void interval_insert_fixup(intervaltree &T,node * &z){
    while(z->p->color == RED){
        if(z->p == z->p->p->left) {
            node * y = z->p->p->right;
            if(y->color == RED){
                z->p->color = BLACK;
                y->color = BLACK;
                z->p->p->color = RED;
                z = z->p->p;
            } else{ 
                if(z == z->p->right){
                    z = z->p;
                    left_rotate(T,z);
                } 
                z->p->color = BLACK;
                z->p->p->color = RED;
                right_rotate(T,z->p->p);
            }
        } else if(z->p == z->p->p->right) {
            node * y = z->p->p->left;
            if(y->color == RED){
                z->p->color = BLACK;
                y->color = BLACK;
                z->p->p->color = RED;
                z = z->p->p;
            } else{
                if(z == z->p->left){
                    z = z->p;
                    right_rotate(T,z);
                } 
                z->p->color = BLACK;
                z->p->p->color = RED;
                left_rotate(T,z->p->p);
            }
        }
    }
    T.root->color= BLACK;
}

node * tree_minimum(intervaltree T,node * x){
    while(x->left != T.nil){
        x = x->left;
    }
    return x;
}

node * tree_successor(intervaltree T,node * x){
    if(x->right != T.nil){
        return tree_minimum(T,x->right);
    }
    node * y = x -> p;
    while(y!=T.nil && x==y->right){
        x = y;
        y = y->p;
    }
    return y;
}

node * tree_search(intervaltree T,node * x,keyType low){
    if(x == T.nil || low == x->low){
        return x;
    }
    if(low < x->low){
        return tree_search(T,x->left,low);
    } else {
        return tree_search(T,x->right,low);
    }
}
void interval_delete(intervaltree &T,node * z){
    node * x,* y;
    if(z->left == T.nil || z->right == T.nil){
        y = z;
    } else {
        y = tree_successor(T,z);
    }
    if(y->left != T.nil){
        x = y->left;
    } else {
        x = y->right;
    }
    x->p = y->p;
    if(y->p == T.nil){
        T.root = x;
    } else {
        if(y == y->p->left){
            y->p->left = x;
        } else {
            y->p->right = x;
        }
    }
    if(y!=z){
        z->low = y->low;
        z->high = y->high;
    }

    // 修改max域
    // y_delete is used to record the node which will be deleted physically
    node * y_delete = y; 
    if(y != z) {
        while(y != T.nil) {
            max_change(T,y);
            y = y->p;
        }
    }
    if(y == z){
        z = z->p; // 若物理删除的就是z结点，则修改其祖先的max即可，否则z本身也要修改
    }
    while(z != T.nil) {
        max_change(T,z);
        z = z->p;
    }

    // 颜色调整
    if(y->color == BLACK){
        interval_delete_fixup(T,x);
    }

    
    free(y_delete);
    return;
}

void interval_delete_fixup(intervaltree &T,node * x){
    while(x!=T.root && x->color == BLACK){
        if(x == x->p->left){
            node * w = x->p->right;
            if(w->color == RED){
                w->color = BLACK;
                x->p->color = RED;
                left_rotate(T,x->p);
                w = x->p->right;
            }
            if(w->left->color == BLACK && w->right->color == BLACK){
                w->color = RED;
                x = x->p;
            } else {
                if(w->right->color == BLACK){
                    w->left->color = BLACK;
                    w->color = RED;
                    right_rotate(T,w);
                    w = x->p->right;
                }
                w->color = x->p->color;
                x->p->color = BLACK;
                w->right->color = BLACK;
                left_rotate(T,x->p);
                x = T.root;
            }
        } else {
            node * w = x->p->left;
            if(w->color == RED){
                w->color = BLACK;
                x->p->color = RED;
                right_rotate(T,x->p);
                w = x->p->left;
            }
            if(w->left->color == BLACK && w->right->color == BLACK){
                w->color = RED;
                x = x->p;
            } else {
                if(w->left->color == BLACK){
                    w->right->color = BLACK;
                    w->color = RED;
                    left_rotate(T,w);
                    w = x->p->left;
                }
                w->color = x->p->color;
                x->p->color = BLACK;
                w->left->color = BLACK;
                right_rotate(T,x->p);
                x = T.root;
            }
        }
    }
    x->color = BLACK;
}

node * interval_search(intervaltree T,keyType low,keyType high){
    node * x = T.root;
    while(x != T.nil && !is_overlap(low,high,x->low,x->high)){
        if(x->left != T.nil && x->left->max >= low){
            x = x->left;
        } else {
            x = x->right;
        }
    }
    return x;
}

/**
 * @description:judge whether the given two intervals overlap
 * @param {two intervals,[low1,high1],[low2,high2]}
 * @return {if overlap ,return 1;else return 0}
 */
int is_overlap(keyType low1,keyType high1,keyType low2,keyType high2){
    if(high1 < low2 || high2 < low1){
        return 0;
    } else {
        return 1;
    }
}

void in_order_print_intervaltree(FILE * f,intervaltree T){
    node * root = T.root;
    if(root == T.nil) {
        return;
    } else {
        in_order_print(f,T,root);
    }
}

void in_order_print(FILE * f,intervaltree &T,node* x){
    if(x == T.nil){
        return;
    }
    in_order_print(f,T,x->left);
    fprintf(f,"%d %d %d\n",x->low,x->high,x->max);
    in_order_print(f,T,x->right);

}

int main(){
    FILE * f_input = fopen("..//input//input.txt", "r" );
    FILE * f_inorder = fopen("..//output//inorder.txt", "w" );
    FILE * f_search = fopen("..//output//search.txt", "w" );
    FILE * f_delete_data = fopen("..//output//delete_data.txt", "w" );
    int n = SIZE;
    
    /* prepare the initilization of intervaltree T */
    intervaltree T;
    node * nil = (node*)malloc(sizeof(node));
    nil->color =BLACK;
    nil->right = nil->left = nil;
    nil->low = nil->high = nil->max = 0;
    init_intervaltree(T,nil);

    // low_input/high_input array are used to record the input left/right end point
    int * low_input = (int *)malloc(sizeof(int)*n);
    int * high_input = (int *)malloc(sizeof(int)*n);
    int x,y;
    /* insert */
    for(int i=0;i < n;i++){
        fscanf(f_input,"%d %d\n",&x,&y);
        low_input[i] = x;
        high_input[i] = y;
        node * z = (node *)malloc(sizeof(node));
        z->low = x;
        z->high = y;
        // insert node z into intervaltree T
        interval_insert(T,z);     
    }
    in_order_print_intervaltree(f_inorder,T);

    /* delete */
    int * del_ran = (int *)malloc(sizeof(int)*(3));
    srand((unsigned)time(0));	// 使用当前时间点重新初始化伪随机数发生器

    // randomly generate 3 intervals that will be deleted
    int flag_new;
    int count =  0;
    while(count < 3) {
        flag_new = 1;
        x = rand() % n;
        for(int i = 0;i < count;i++){
            if(x == del_ran[i]){
                flag_new = 0;
                break;
            }
        }
        if(!flag_new){
            continue;
        } else {
            del_ran[count] = x;
            count ++;
        }
    }

    for(int i=0;i<3;i++){
        // low_input[del_ran[i]] is the left end point of the interval that will be deleted
        node * z = tree_search(T,T.root,low_input[del_ran[i]]);
        if(z!=T.nil){
            fprintf(f_delete_data,"[%d,%d] ",z->low,z->high);
            // delete node z from intervaltree T
            interval_delete(T,z);
        }
    }
    fprintf(f_delete_data,"\n");
    in_order_print_intervaltree(f_delete_data,T);

    /* search */
    // randomly generate 2 intervals that will be searched
    keyType low_search[3],high_search[3];
    for(int i=0;i<2;i++){
        low_search[i] = rand()%50;
        high_search[i] = rand()%(50-low_search[i]) + low_search[i] + 1;
    }
    // the third interval is [26,29]
    low_search[2] = 26;
    high_search[2] = 29;
    for(int i=0;i<3;i++){
        node * x = interval_search(T,low_search[i],high_search[i]);
        fprintf(f_search,"[%d,%d] ",low_search[i],high_search[i]);
        if(x != T.nil){
            fprintf(f_search,"[%d,%d] \n",x->low,x->high);
        } else {
            fprintf(f_search,"NULL\n");
        }
    }
    
    
    fclose(f_input);
    fclose(f_inorder);
    fclose(f_delete_data);
    fclose(f_search);
}