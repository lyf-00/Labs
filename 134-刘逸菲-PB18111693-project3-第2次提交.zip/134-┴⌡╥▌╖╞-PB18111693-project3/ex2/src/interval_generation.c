/*
 * @Author: lyf
 * @Date: 2020-12-22 19:19:29
 * @LastEditors: lyf
 * @LastEditTime: 2020-12-24 00:03:11
 * @FilePath: \134-刘逸菲-PB18111693-project3\ex2\src\interval_generation.c
 */

# include<stdio.h>
# include<math.h>
# include<stdlib.h>
# include <time.h>
# include<string.h>
# define SIZE 30
/**
 * @description: generate SIZE intervals with different left end points,all intervals is in [0,25] or [30,50]
 * @param {*}
 * @return {*}
 */
int main() {
	FILE * f = fopen("..//input//input.txt", "w" );
    // random array is used to record generated intervals 
    int random[SIZE][2];
    memset(random,0,sizeof(int) * SIZE * 2);
	srand((unsigned)time(0));	// 使用当前时间点重新初始化伪随机数发生器

    int x,y;
    int new;
    int count =  0;
    while(count < SIZE) {
        new = 1;
        x = rand() % 50;
        if(x >= 25 && x < 30){
            continue;
        }
        // judge whether x is a repetitive left end point
        for(int i = 0;i < count;i++){
            if(x == random[i][0]){
                new = 0;
                break;
            }
        }
        if(!new){
            continue;
        } else {
            random[count][0] = x;
            // 确定右端点
            if(x < 25){
                y = x;
                while(y <= x){
                    y = rand()%25 + 1;
                }          
                random[count][1] = y;      
            } else if(x >= 30){
                y = x;
                while(y <= x){
                    y = rand()%50 + 1;
                }          
                random[count][1] = y;
            }
            count ++;
        }
    }

	for (int i = 0; i < SIZE; i++) {
		fprintf(f, "%d %d\n",random[i][0],random[i][1]);
	}

	fclose(f);
}