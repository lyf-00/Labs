/*
 * @Author: lyf
 * @Date: 2020-12-22 19:19:29
 * @LastEditors: lyf
 * @LastEditTime: 2020-12-23 23:59:13
 * @FilePath: \134-刘逸菲-PB18111693-project3\ex1\src\number_generation.c
 */

# include<stdio.h>
# include<math.h>
# include<stdlib.h>
# include <time.h>
# include<string.h>
# define SIZE 100
/**
 * @description:generate SIZE distinct positive integers less than 65535 
 * @param {*}
 * @return {*}
 */
int main() {
	FILE * f = fopen("..//input//input.txt", "w" );

    int random[SIZE];
    memset(random,0,sizeof(int) * SIZE);
	srand((unsigned)time(0));	// 使用当前时间点重新初始化伪随机数发生器

    int x;
    int new;
    int count =  0; // count is used to record how many integers have been generated
    while(count < SIZE) {
        new = 1;
        x = rand();
        if(x < -65535 || x > 65535){
            continue;
        }
        // judge whether the new rand is repetitive
        for(int i = 0;i < count;i++){
            if(x == random[i]){
                new = 0;
                break;
            }
        }
        if(!new){
            continue;
        } else {
            random[count] = x;
            count ++;
        }
    }

	for (int i = 0; i < SIZE; i++) {
		fprintf(f, "%d\n",random[i]);
	}

	fclose(f);
	getchar();
}