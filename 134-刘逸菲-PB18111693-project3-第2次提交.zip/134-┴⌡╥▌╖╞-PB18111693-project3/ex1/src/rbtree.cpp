/*
 * @Author: lyf
 * @Date: 2020-12-23 23:58:35
 * @LastEditors: lyf
 * @LastEditTime: 2020-12-24 00:02:07
 * @FilePath: \134-刘逸菲-PB18111693-project3\ex1\src\rbtree.cpp
 */
# include<stdio.h>
# include<stdlib.h>
# include <time.h>
# include<math.h>
# include<windows.h>

# define RED true
# define BLACK false

typedef int keyType;
typedef bool colortype;

/* definition of structs */
struct node{
    keyType key;
    struct node * p,* right,* left;
    colortype color;
};
struct rbtree {
    struct node * root;
    struct node * nil;
};
typedef struct node node;
typedef struct rbtree rbtree;

// function declaration
void init_rbtree(rbtree &T,node * &nil);
void left_rotate(rbtree &T,node * x);
void right_rotate(rbtree &T,node * x);
void rb_insert(rbtree &T,node * &z);
void rb_insert_fixup(rbtree &T,node * &z);
void in_order_print_rbtree(FILE * f,rbtree T);
void in_order_print(FILE * f,rbtree &T,node* x);
node * tree_minimum(rbtree T,node * x);
node * tree_successor(rbtree T,node * x);
node * tree_search(rbtree T,node * x,keyType key);
void rb_delete(rbtree &T,node * z);
void rb_delete_fixup(rbtree &T,node * x);

/**
 * @description: init a red black tree
 * @param {T is a struct rbtree, nil is used as T.nil}
 * @return {void}
 */
void init_rbtree(rbtree &T,node * &nil){
    T.nil = nil;
    T.root = T.nil;
}

/**
 * @description: left rotate at node x
 * @param {*}
 * @return {void}
 */
void left_rotate(rbtree &T,node * x){
    node * y = x->right;
    x->right = y->left;
    if (y->left != T.nil){
        y->left->p = x;
    }
    y->p = x->p;
    if(x->p == T.nil){
        T.root = y;
    } else if(x == x->p->left){
        x->p->left = y;
    } else {
        x->p->right = y;
    }
    y->left = x;
    x->p = y;
}

void right_rotate(rbtree &T,node * x){ 
    node * y = x->left;
    x->left = y->right;
    if (y->right != T.nil){
        y->right->p = x;
    }
    y->p = x->p;
    if(x->p == T.nil){
        T.root = y;
    } else if(x == x->p->left){
        x->p->left = y;
    } else {
        x->p->right = y;
    }
    y->right = x;
    x->p = y;
}

/**
 * @description:insert node z into rbtree T 
 * @param {*}
 * @return {void}
 */
void rb_insert(rbtree &T,node * &z){
    node * y = T.nil;
    node * x = T.root;
    while(x != T.nil){
        y = x;
        if(z->key < x->key){
            x = x->left;
        } else {
            x = x->right;
        }
    }
    z->p = y;
    if(y == T.nil){
        T.root = z;
    } else if(z->key < y->key){
        y->left = z;
    } else {
        y->right = z;
    }
    z->left = z->right = T.nil;
    z->color = RED;
    rb_insert_fixup(T,z);
}

/**
 * @description: keep the red-black tree properties after inserting a node into it
 * @param {z is the node inserted}
 * @return {void}
 */
void rb_insert_fixup(rbtree &T,node * &z){
    while(z->p->color == RED){
        if(z->p == z->p->p->left) {
            node * y = z->p->p->right;
            if(y->color == RED){
                z->p->color = BLACK;
                y->color = BLACK;
                z->p->p->color = RED;
                z = z->p->p;
            } else{ 
                if(z == z->p->right){
                    z = z->p;
                    left_rotate(T,z);
                } 
                z->p->color = BLACK;
                z->p->p->color = RED;
                right_rotate(T,z->p->p);
            }
        } else if(z->p == z->p->p->right) {
            node * y = z->p->p->left;
            if(y->color == RED){
                z->p->color = BLACK;
                y->color = BLACK;
                z->p->p->color = RED;
                z = z->p->p;
            } else{
                if(z == z->p->left){
                    z = z->p;
                    right_rotate(T,z);
                } 
                z->p->color = BLACK;
                z->p->p->color = RED;
                left_rotate(T,z->p->p);
            }
        }
    }
    T.root->color= BLACK;
}

/**
 * @description: find the node with minimum key in all children nodes of x
 * @param {*}
 * @return {pointer to the minimum node}
 */
node * tree_minimum(rbtree T,node * x){
    while(x->left != T.nil){
        x = x->left;
    }
    return x;
}

/**
 * @description: find the successor node of x in the rbtree T
 * @param {*}
 * @return {pointer to the successor node}
 */
node * tree_successor(rbtree T,node * x){
    if(x->right != T.nil){
        return tree_minimum(T,x->right);
    }
    node * y = x -> p;
    while(y!=T.nil && x==y->right){
        x = y;
        y = y->p;
    }
    return y;
}

/**
 * @description: find the node with specified key in children nodes of x
 * @param {*}
 * @return {pointer to the node with specified key}
 */
node * tree_search(rbtree T,node * x,keyType key){
    if(x == T.nil || key == x->key){
        return x;
    }
    if(key < x->key){
        return tree_search(T,x->left,key);
    } else {
        return tree_search(T,x->right,key);
    }
}
/**
 * @description: delete node z in rbtree T
 * @param {*}
 * @return {void}
 */
void rb_delete(rbtree &T,node * z){
    node * x,* y;
    if(z->left == T.nil || z->right == T.nil){
        y = z;
    } else {
        y = tree_successor(T,z);
    }
    if(y->left != T.nil){
        x = y->left;
    } else {
        x = y->right;
    }
    x->p = y->p;
    if(y->p == T.nil){
        T.root = x;
    } else {
        if(y == y->p->left){
            y->p->left = x;
        } else {
            y->p->right = x;
        }
    }
    if(y!=z){
        z->key = y->key;
    }
    if(y->color == BLACK){
        rb_delete_fixup(T,x);
    }
    free(y);
    return;
}

/**
 * @description: keep the red-black tree properties after deleting a node from it
 * @param {*}
 * @return {void}
 */
void rb_delete_fixup(rbtree &T,node * x){
    while(x!=T.root && x->color == BLACK){
        if(x == x->p->left){
            node * w = x->p->right;
            if(w->color == RED){
                w->color = BLACK;
                x->p->color = RED;
                left_rotate(T,x->p);
                w = x->p->right;
            }
            if(w->left->color == BLACK && w->right->color == BLACK){
                w->color = RED;
                x = x->p;
            } else {
                if(w->right->color == BLACK){
                    w->left->color = BLACK;
                    w->color = RED;
                    right_rotate(T,w);
                    w = x->p->right;
                }
                w->color = x->p->color;
                x->p->color = BLACK;
                w->right->color = BLACK;
                left_rotate(T,x->p);
                x = T.root;
            }
        } else {
            node * w = x->p->left;
            if(w->color == RED){
                w->color = BLACK;
                x->p->color = RED;
                right_rotate(T,x->p);
                w = x->p->left;
            }
            if(w->left->color == BLACK && w->right->color == BLACK){
                w->color = RED;
                x = x->p;
            } else {
                if(w->left->color == BLACK){
                    w->right->color = BLACK;
                    w->color = RED;
                    left_rotate(T,w);
                    w = x->p->left;
                }
                w->color = x->p->color;
                x->p->color = BLACK;
                w->left->color = BLACK;
                right_rotate(T,x->p);
                x = T.root;
            }
        }
    }
    x->color = BLACK;
}

/**
 * @description: print all nodes of T into File f by in order traversal
 * @param {*}
 * @return {void}
 */
void in_order_print_rbtree(FILE * f,rbtree T){
    node * root = T.root;
    if(root == T.nil) {
        return;
    } else {
        in_order_print(f,T,root);
    }
}

void in_order_print(FILE * f,rbtree &T,node* x){
    if(x == T.nil){
        return;
    }
    in_order_print(f,T,x->left);
    fprintf(f,"%d ",x->key);
    in_order_print(f,T,x->right);

}

int main(){
    // variables associated with running time
    LARGE_INTEGER nFreq;
    LARGE_INTEGER nBeginTime;
    LARGE_INTEGER nEndTime;
    double execution_time;

    QueryPerformanceFrequency(&nFreq);

    FILE * f_inorder = fopen("..//output//inorder.txt", "w" );
    FILE * f_time1 = fopen("..//output//time1.txt", "w" );
    FILE * f_delete_data = fopen("..//output//delete_data.txt", "w" );
    FILE * f_time2 = fopen("..//output//time2.txt", "w" );
    
    // size = 20,40,60,80,100
    for(int i=1;i<=5;i++){
        FILE * f_input = fopen("..//input//input.txt", "r" );
        int n = 20*i;

        /* insert */
        // prepare the initialization of rbtree T
        rbtree T;
        node * nil = (node*)malloc(sizeof(node));
        nil->color =BLACK;
        nil->right = nil->left = nil;
        init_rbtree(T,nil);

        // input_rand array is used to record all input keys
        int* input_rand = (int *)malloc(sizeof(int)*n);
        int x; 
        QueryPerformanceCounter(&nBeginTime);
        for(int i=0;i < n;i++){
            fscanf(f_input,"%d\n",&x);
            input_rand[i] = x;
            node * z = (node *)malloc(sizeof(node));
            z->key = x;
            // insert node z into rbtree T
            rb_insert(T,z);
        }
        QueryPerformanceCounter(&nEndTime);
        execution_time = (double)(nEndTime.QuadPart-nBeginTime.QuadPart)/(double)nFreq.QuadPart;
        fprintf(f_time1,"%lf s\n",execution_time);
        in_order_print_rbtree(f_inorder,T);
        fprintf(f_inorder,"\n");

        /* delete */
        int * del_ran = (int *)malloc(sizeof(int)*(n/4));
        srand((unsigned)time(0));	// 使用当前时间点重新初始化伪随机数发生器

        // randomly generate n/4 nodes that will be deleted
        int flag_new;
        int count =  0;
        while(count < n/4) {
            flag_new = 1;
            x = rand() % n;
            for(int i = 0;i < count;i++){
                if(x == del_ran[i]){
                    flag_new = 0;
                    break;
                }
            }
            if(!flag_new){
                continue;
            } else {
                del_ran[count] = x;
                count ++;
            }
        }

        QueryPerformanceCounter(&nBeginTime);
        for(int i=0;i<n/4;i++){
            // input_rand[del_ran[i]] is the key of the node that will be deleted
            node * z = tree_search(T,T.root,input_rand[del_ran[i]]);    
            if(z!=T.nil){
                // delete node z from rbtree T
                rb_delete(T,z);              
            }
        }
        QueryPerformanceCounter(&nEndTime);
        execution_time = (double)(nEndTime.QuadPart-nBeginTime.QuadPart)/(double)nFreq.QuadPart;
        
        fprintf(f_time2,"%lf s\n",execution_time);
        for(int i=0;i<n/4;i++){
            fprintf(f_delete_data,"%d ",input_rand[del_ran[i]]);
        }
        fprintf(f_delete_data,"\n");
        in_order_print_rbtree(f_delete_data,T);
        fprintf(f_delete_data,"\n");
        fclose(f_input);
    }



    fclose(f_inorder);
    fclose(f_time1);
    fclose(f_delete_data);
    fclose(f_time2);
}