/*
 * @Author: lyf
 * @Date: 2020-12-08 16:03:38
 * @LastEditTime: 2020-12-08 21:16:19
 * @LastEditors: lyf
 * @Description: use Recursive FFT to compute the DFT of input data
 * @FilePath: \134-刘逸菲-PB18111693-project2\ex2\src\FFT.c
 */

# include<math.h>  
# include<stdlib.h>
# include<windows.h>
# include<stdio.h>
const double pi = 3.1415926;
 
// 复数的结构体定义
typedef struct complex{
    double real;
    double imag;
} complex;
// 复数加
complex add(complex a,complex b){
    complex c;
    c.real = a.real+b.real;
    c.imag = a.imag+b.imag;
    return c;
}
complex sub(complex a,complex b){
    complex c;
    c.real = a.real-b.real;
    c.imag = a.imag-b.imag;
    return c;
}
complex mul(complex a,complex b){
    complex c;
    c.real = a.real*b.real - a.imag*b.imag;
    c.imag = a.imag*b.real + a.real*b.imag;
    return c;
}




/**
 * @description: Recursive FFT,compute the DFT of a vector of n elements
 * @param {n:the degree bound of a polynomial}
 * @param {a:coefficients of every term}
 * @param {y:result}
 * @return {void}
 */
void Recursive_FFT(int n, int a[], complex y[]) {
    if (n == 1){
        y[0].real = a[0];
        y[0].imag = 0;
        return;
    }
    
    complex x;
    x.real = 0;
    x.imag = 2 * pi / n; 

    complex wn;
    wn.real =  cos(x.imag);
    wn.imag =  sin(x.imag);
    complex w;
    w.real = 1;
    w.imag = 0;

    int* a0 = (int*)malloc(sizeof(int) * (n / 2));
    int* a1 = (int*)malloc(sizeof(int) * (n / 2));

    for (int i = 0; i < n; i = i + 2) {
        a0[i/2] = a[i];
        a1[i/2] = a[i + 1];
    }

    complex* y0 = (complex*) malloc(sizeof(complex) * (n / 2));
    complex* y1 = (complex*) malloc(sizeof(complex) * (n / 2));

    Recursive_FFT(n / 2, a0, y0);
    Recursive_FFT(n / 2, a1, y1);
    for (int k = 0; k < n / 2; k++) {
        y[k] = add(y0[k],mul(w,y1[k]));
        y[k + n / 2] = sub(y0[k],mul(w,y1[k]));
        w = mul(w,wn);
    }
    free(a);
    free(y0);
    free(y1);
}

int main() {
    LARGE_INTEGER nFreq;
    LARGE_INTEGER nBeginTime;
    LARGE_INTEGER nEndTime;
    double time;
    FILE * ftime = fopen("../output/time.txt","w");

    QueryPerformanceFrequency(&nFreq);

    FILE * finput = fopen("../input/2_2_input.txt","r");
    if(!finput){
        printf("can not open the input file");
    }
    FILE * fresult = fopen("../output/result.txt","w");
    if(!fresult){
        printf("can not open the result file");
    }

    int n;
    for (int k=0;k<6;k++){
        fscanf(finput,"%d\n",&n);
        int * a = (int *)malloc(sizeof(int)*n);
        complex *y =  malloc(sizeof(complex) * (n));
        for(int i=0;i < n ;i++){
            fscanf(finput,"%d ",&a[i]);
        }

        QueryPerformanceCounter(&nBeginTime);   // record begin time
        Recursive_FFT(n, a, y);
        QueryPerformanceCounter(&nEndTime);     // record end time  
         
        time = (double)(nEndTime.QuadPart-nBeginTime.QuadPart)/(double)nFreq.QuadPart;
        fprintf(ftime,"%lf s\n",time);
        for (int i = 0; i < n; i++) {
            fprintf(fresult,"%lf ", y[i].real);
        }
        fprintf(fresult,"\n");
        free(a);
        free(y);
    }
    
    fclose(fresult);
    fclose(finput);
    fclose(ftime);
    getchar();
}