/*
 * @Author: lyf
 * @Date: 2020-12-07 20:03:49
 * @LastEditTime: 2020-12-08 21:15:14
 * @LastEditors: lyf
 * @Description: use dynamic planning to find the optimal scheme of matrix chain multiplication
 * @FilePath: \134-刘逸菲-PB18111693-project2\ex1\src\matrix_chain.c
 */
# include<stdio.h>  
# include<stdlib.h>
# include<windows.h>
// #include <unistd.h>
#define INFINITY 9223372036854775807
void matrix_chain_order(long long p [], int size,FILE * fresult);
void print_optimal_parens(int ** s,int i,int j,FILE * fresult);


/**
 * @description:use dynamic planning to find the optimal scheme of matrix chain multiplication 
 * @param {p: matrix size <p0,p1,p2,..pn>}
 * @param {size:number of matrix +1,size of p}
 * @param {fresult:pointer of the output file}
 * @return {void}
 */
void matrix_chain_order(long long p [], int size,FILE * fresult) {
    // p存放[p0,p1,p2,...pn],size = n+1
    int n = size - 1;
    // m[1..n,1..n]存放最小乘法次数,s[1..n-1,1..n-1]存放切分位置
    // malloc and init m
    long long ** m = (long long**)malloc(sizeof(long long *)*(n+1));
    for(int i = 0;i < n+1;i++){
        m[i] = (long long *)malloc(sizeof(long long)*(n+1));
        memset(m[i],0,sizeof(long long)*(n+1));
    }
    for(int i=1;i <= n;i++){
        m[i][i] = 0;
    }
    // malloc s
    int ** s = (int **)malloc(sizeof(int *)*(n));
    for(int i = 0;i < n;i++){
        s[i] = (int *)malloc(sizeof(int)*(n));
        memset(s[i],0,sizeof(int)*(n));
    }

    for(int l = 2;l <= n;l++){
        for (int i=1;i <= n-l+1;i++){
            int j = i + l - 1;
            m[i][j] = INFINITY;
            for(int k = i;k <= j-1;k++){
                long long q = m[i][k] + m[k+1][j] + p[i-1]*p[k]*p[j];
                if (q < m[i][j]){
                    m[i][j] = q;
                    s[i][j] = k;
                }
            }

        }
    }

    fprintf(fresult,"%lld\t",m[1][n]);
    fprintf(fresult,"\n");
    print_optimal_parens(s,1,n,fresult);
    fprintf(fresult,"\n");
    // free
    for(int i = 0;i < n+1;i++){
        free(m[i]);
    }

}

/**
 * @description: Print the bracketing scheme of matrix chain multiplication
 * @param {s:the best position of partition}
 * @param {i:begin position}
 * @param {j:end position}
 * @return {void}
 */
void print_optimal_parens(int ** s,int i,int j,FILE * fresult){
    if(i == j){
        // printf("A%d",i);
        fprintf(fresult,"A%d",i);
    } else {
        //printf("(");
        fprintf(fresult,"(");
        print_optimal_parens(s,i,s[i][j],fresult);
        print_optimal_parens(s,s[i][j]+1,j,fresult);
        //printf(")");
        fprintf(fresult,")");
    }
}

int main(){

    LARGE_INTEGER nFreq;
    LARGE_INTEGER nBeginTime;
    LARGE_INTEGER nEndTime;
    double time;
    FILE * ftime = fopen("../output/time.txt","w");

    QueryPerformanceFrequency(&nFreq);

    FILE * finput = fopen("../input/2_1_input.txt","r");
    if(!finput){
        printf("can not open the input file");
    }
    FILE * fresult = fopen("../output/result.txt","w");
    if(!fresult){
        printf("can not open the result file");
    }

    long long * p;
    int size;
    for(int k = 0;k<5;k++){
        fscanf(finput,"%d\n",&size);
        size += 1;
        p = (long long *)malloc(sizeof(long long) * size);
        for(int i=0;i < size ;i++){
            fscanf(finput,"%lld ",&p[i]);
   
        }
  
        QueryPerformanceCounter(&nBeginTime);   // record begin time

        matrix_chain_order(p,size,fresult);

        QueryPerformanceCounter(&nEndTime);     // record end time   
        time = (double)(nEndTime.QuadPart-nBeginTime.QuadPart)/(double)nFreq.QuadPart;
        fprintf(ftime,"%lf s\n",time);
    }
    fclose(fresult);
    fclose(finput);
    fclose(ftime);
    getchar();
    getchar();
    return 1;
}