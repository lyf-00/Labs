
# include<stdio.h>
# include<math.h>
# include<stdlib.h>
# include <time.h>

int main() {
	FILE * f = fopen("E://STUDY//Algorithm//exp1//input//input.txt", "w" );
	srand((unsigned)time(0));	// 使用当前时间点重新初始化伪随机数发生器
	for (int i = 0; i < pow(2, 18); i++) {
		fprintf(f, "%d\n", rand());
	}
	fclose(f);
	getchar();
}