# include<stdio.h>
# include<stdlib.h>
# include<string.h>
# include<math.h>
# include<windows.h>

void print_array(int * a,int length){
    printf("print_array:\n");
    for(int i =0;i<length;i++){
        printf("%d\n",a[i]);
    }
}
int insert_sort(int* a,int length){

    // a是要排序的数组首地址，length是该数组长度
    // print_array(a,length);
    int i;
    for(int j = 1;j < length;j++){
        int key = a[j];
        i = j - 1;
        while(a[i] > key && i >= 0){
            a[i+1] = a[i];
            i = i - 1;
        }
        a[i+1] = key;
    }
}

int merge(int *a,int p,int q,int r){
    // a为数组首地址，p-q，q+1-r两段分别有序

    // left,right各多一个元素，用来放哨兵牌
    unsigned int * left = (unsigned int*)malloc(sizeof(unsigned int) * ((q-p+1)+1)); 
    unsigned int * right = (unsigned int*)malloc(sizeof(unsigned int) * ((r-q) + 1));
    memcpy(left,&a[p],sizeof(int) * (q-p+1));
    memcpy(right,&a[q+1],sizeof(int) *(r-q));
    left[q-p+1] = pow(2,15) + 1;
    right[r-q+1] = pow(2,15) + 1;

    int i = 0;
    int j = 0;
    for(int k = p;k <= r;k++){
        if(left[i] < right[j]){
            a[k] = left[i];
            i++;
        } else {    //right[j] >= left[i]
            a[k] = right[j];
            j++;
        }
    }
}

int merge_sort(int *a,int p,int r){
    // a为要排序的数组首地址
    if(p < r){
        int q = (p+r)/2;
        merge_sort(a,p,q);
        merge_sort(a,q+1,r);
        merge(a,p,q,r);
    }
}

int max_heapify(int * a,int heap_size,int i){
    // a为数组首地址（有效数据从1开始），heap_size为堆大小，i的左右子树都已是最大堆
    int left = 2*i;
    int right = 2*i + 1;
    int largest = i;
    if(left <= heap_size && a[left] > a[i]){    // 注意判断条件是<=
        largest = left;
    }
    if(right <= heap_size && a[right] > a[largest]){
        largest = right;
    }

    if(largest != i){
        int tmp = a[largest];
        a[largest] = a[i];
        a[i] = tmp;
        max_heapify(a,heap_size,largest);
    }
}

int build_max_heap(int *a,int length){
    // a是要建堆的数组起始地址，注意有效数据从1开始
    for(int i = length/2;i >= 1;i--){
        max_heapify(a,length,i);
    }
}

int heap_sort(int * a,int length){
    // a是要排序的数组起始地址，注意有效数据从1开始
    int heap_size = length;
    build_max_heap(a,heap_size);
    int tmp;
    
    // printf("heap_sort:after build \n");
    // print_array(a,length+1);
    for(int i = length;i > 1;i--){
        tmp = a[1];
        a[1] = a[i];
        a[i] = tmp;
        heap_size--;
        max_heapify(a,heap_size,1);
    }
}

int partition(int *a,int p,int r){
    // a为数组首地址，p-r进行partition，返回值为i，p-(i-1)的值都小于等于a[r]
    int key = a[r];
    int i = p - 1;
    int tmp;
    for(int j = p;j < r;j++){
        if(a[j] <= key){
            i++;
            tmp = a[i];
            a[i] = a[j];
            a[j] = tmp;
        }
    }
    i++;
    a[r] = a[i];
    a[i] = key;
    return i;
}

int quick_sort(int * a,int p,int r){
    if(p<r){
        int q = partition(a,p,r);  // 返回时，p~(q-1),q,(q+1)~r三段
        quick_sort(a,p,q-1);
        quick_sort(a,q+1,r);  // 注意是q+1
    }
}

int counting_sort(int * a,int length,int * res,int k){
    int * c = (int*)malloc(sizeof(int) * (k+1));
    memset(c,0,sizeof(int) * (k+1));
    for(int i = 0;i < length;i++){
        c[a[i]] ++;
    }

    for(int i = 1;i < k + 1;i++){
        c[i] = c[i] + c[i-1];
    }

    for(int j = length - 1;j >= 0;j--){
        // 注意循环条件与循环内容
        res[c[a[j]]-1] = a[j];
        c[a[j]]--;
    }
    free(c);
}

int main(){

    // variables associated with running time
    LARGE_INTEGER nFreq;
    LARGE_INTEGER nBeginTime;
    LARGE_INTEGER nEndTime;
    double time;
    FILE * ftime;

    QueryPerformanceFrequency(&nFreq);

    FILE * f = fopen("E://STUDY//Algorithm//exp1//input//input.txt","r");

    // variables associated with output file path
    char path[100] = "E://STUDY//Algorithm//exp1//output//";
    int path_len = strlen(path);
    

    for(int j =3 ;j <= 18;j = j + 3){

        // open output file to contain results
        char file_name[20] = "result_";
        // convert input_size n into char,example:n = 18,file_name[7,8]="18"
        if(j >= 10){
            file_name[7] = '1';
            file_name[8] = '0' + j % 10;
            file_name[9] = 0;   // end of string
        } else {
            file_name[7] = '0' + j;
            file_name[8] = 0;
        }

        strcpy(file_name,strcat(file_name,".txt"));

        FILE * finsert = fopen(strcat(strcat(path,"insert_sort//"),file_name),"w");
        path[path_len] = 0;     // delete "insert_sort" in path
        FILE * fmerge = fopen(strcat(strcat(path,"merge_sort//"),file_name),"w");
        path[path_len] = 0;
        FILE * fheap = fopen(strcat(strcat(path,"heap_sort//"),file_name),"w");
        path[path_len] = 0;
        FILE * fquick = fopen(strcat(strcat(path,"quick_sort//"),file_name),"w");
        path[path_len] = 0;
        FILE * fcounting = fopen(strcat(strcat(path,"counting_sort//"),file_name),"w");
        path[path_len] = 0;

        // read input data into array a
        int n = pow(2,j);   // n is input data size
        int * a = (int*)malloc(sizeof(int) * (n + 1));
        for(int i=0;i < n;i++){
            fscanf(f,"%d\n",&a[i]);
        }
        
        // array res contains a copy of array a
        int * res = (int*)malloc(sizeof(int) * (n + 1));

        // insert_sort
        memcpy(res,a,sizeof(int)*(n+1));  // prepare array to be sorted
        ftime = fopen(strcat(strcat(path,"insert_sort//"),"time.txt"),"a");
        path[path_len] = 0;
        QueryPerformanceCounter(&nBeginTime);   // record begin time

        insert_sort(res,n);

        QueryPerformanceCounter(&nEndTime);     // record end time
        time = (double)(nEndTime.QuadPart-nBeginTime.QuadPart)/(double)nFreq.QuadPart;
        fprintf(ftime,"%d:%lf\n",n,time);
        fclose(ftime);

        for(int i = 0;i<n;i++){
            fprintf(finsert,"%d\n",res[i]);
        }

        fclose(finsert);

        // merge_sort
        memcpy(res,a,sizeof(int)*(n+1));
        ftime = fopen(strcat(strcat(path,"merge_sort//"),"time.txt"),"a");
        path[path_len] = 0;
        QueryPerformanceCounter(&nBeginTime);

        merge_sort(res,0,n-1);

        QueryPerformanceCounter(&nEndTime);
        time = (double)(nEndTime.QuadPart-nBeginTime.QuadPart)/(double)nFreq.QuadPart;
        fprintf(ftime,"%d:%lf\n",n,time);

        fclose(ftime);

        for(int i = 0;i<n;i++){
            fprintf(fmerge,"%d\n",res[i]);
        }
        fclose(fmerge);

        // heap_sort
        memcpy(res + 1,a,sizeof(int)*(n+1));
        ftime = fopen(strcat(strcat(path,"heap_sort//"),"time.txt"),"a");
        path[path_len] = 0;
        QueryPerformanceCounter(&nBeginTime);

        heap_sort(res,n);

        QueryPerformanceCounter(&nEndTime);
        time = (double)(nEndTime.QuadPart-nBeginTime.QuadPart)/(double)nFreq.QuadPart;
        fprintf(ftime,"%d:%lf\n",n,time);

        fclose(ftime);

        
        for(int i = 1;i<n+1;i++){
            fprintf(fheap,"%d\n",res[i]);
        }  
        fclose(fheap);

        // quick_sort
        memcpy(res,a,sizeof(int)*(n+1));
        ftime = fopen(strcat(strcat(path,"quick_sort//"),"time.txt"),"a");
        path[path_len] = 0;
        QueryPerformanceCounter(&nBeginTime);

        quick_sort(res,0,n-1);

        QueryPerformanceCounter(&nEndTime);
        time = (double)(nEndTime.QuadPart-nBeginTime.QuadPart)/(double)nFreq.QuadPart;
        fprintf(ftime,"%d:%lf\n",n,time);

        fclose(ftime);

        for(int i = 0;i<n;i++){
            fprintf(fquick,"%d\n",res[i]);

        }
        fclose(fquick);

        // counting sort
        memcpy(res,a,sizeof(int)*(n+1));
                ftime = fopen(strcat(strcat(path,"counting_sort//"),"time.txt"),"a");
        path[path_len] = 0;
        QueryPerformanceCounter(&nBeginTime);

        counting_sort(a,n,res,pow(2,15)-1);

        QueryPerformanceCounter(&nEndTime);
        time = (double)(nEndTime.QuadPart-nBeginTime.QuadPart)/(double)nFreq.QuadPart;
        fprintf(ftime,"%d:%lf\n",n,time);

        fclose(ftime);

        
        for(int i = 0;i<n;i++){
            fprintf(fcounting,"%d\n",res[i]);
        }
        fclose(fcounting);
    }
    
    fclose(f);
    printf("end");
    getchar();
}
